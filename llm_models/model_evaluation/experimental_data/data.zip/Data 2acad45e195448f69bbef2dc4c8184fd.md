# Data

Create a queue and add the starting vertex to it.
Create an array to keep track of the distances from the starting vertex to all other vertices. Initialize all distances to infinity except for the starting vertex, which should have a distance of 0.
While the queue is not empty, dequeue the next vertex.
For each neighbor of the dequeued vertex that has not been visited, set its distance to the distance of the dequeued vertex plus 1 and add it to the queue.
Repeat steps 3-4 until the queue is empty.
The distances array now contains the shortest path distances from the starting vertex to all other vertices.

# Java

[Code Samples Java](Data%202acad45e195448f69bbef2dc4c8184fd/Code%20Samples%20Java%20f3dc7d9fa85542838b732b56538eb68e.csv)

# CPP

[Code Samples CPP](Data%202acad45e195448f69bbef2dc4c8184fd/Code%20Samples%20CPP%20d762923691d84fd6bdfea1af11113fa6.csv)

# TypeScript

[Code Samples (1)](Data%202acad45e195448f69bbef2dc4c8184fd/Code%20Samples%20(1)%20c1c7e20c914342b4a24f34c1236403f6.csv)

# GO

[Code Samples (2)](Data%202acad45e195448f69bbef2dc4c8184fd/Code%20Samples%20(2)%208910fba0c0314560b4049bd9482bea0c.csv)